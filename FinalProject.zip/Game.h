#ifndef GAME_H
#define GAME_H
#include <string>


class Game
{
    private:

    int players;
    std::string playernames;

    public:
    
    void play();
};


#endif