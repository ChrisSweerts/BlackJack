#include "House.h"

void House :: flipFirstCard(){
    cardshand[0].flip();
}