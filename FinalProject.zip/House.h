#ifndef HOUSE_H
#define HOUSE_H
#include "GenericPlayer.h"

class House : public GenericPlayer
{
    private:

        
    public:

    void flipFirstCard();


};

#endif